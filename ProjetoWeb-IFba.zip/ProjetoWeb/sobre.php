<!DOCTYPE html>
<html  lang = "pt-br">
<head>
	<title>Painel</title>
	<link type="text/css" rel="stylesheet" href="css/estilopainel.css"/>
	<link real="stylesheet" type="text/css" heref="css/normalize.css"/>

</head>
	<body>
	<meta charset="UTF-8">
		<div id="header">
			<div id="navbar">
				<ul>
					<li><a href="http://localhost/ProjetoWeb/painel.php">Principal</li>
					<li><a href="http://127.0.0.1/ProjetoWeb/sobre.php">Sobre o Projeto</a></li>
					<li><a href="http://localhost/ProjetoWeb/turma.php">Sobre a turma</a></li>
					<li><a href="http://localhost/ProjetoWeb/contato.php">Contato</a></li>
				</ul>
			</div>
			<h2>SOBRE O PROJETO</h2>
		</div>

		<div id="left">
		<img src="img/professor.jpg."/>
		<p> 
		O projeto deste site é parte obrigatoria da disciplina de Web ministrada pelo professor Moises Leite. O site Web visa os conceitos de HTML e CSS como parte da avaliação. Os docentes envolvidos no projeto são: Elton Oliveira e Rosberg Guedes, ambos alunos do IFBA campus Feira de Santana, Informática Subsequente.</p>
		</div>

		<div id="right">
		<table>
			<th colspan="3">Rede Social</th>
			<tr>
				<td><img src="img/jean.jpg"/></a<></td>
				<td><img src="img/elton.jpg"/></td>
				<td><img src="img/kaique.jpg"/></td>
			</tr>
			<tr>
				<td><img src="img/monalisa.jpg"/></td>
				<td><img src="img/lais.jpg"/></td>
				<td><img src="img/Suzan.jpg"/></td>
			</tr>
			<tr>
				<td><img id="bottom_left" src="img/rosberg.jpg"/></td>
				<td><img src="img/jeferson.jpg"></td>
				<td><img id="bottom_right" src="img/wendell.jpg"/></td>
			</tr>
		</table>
		</div>
		<div id="footer">
			<div id="button">
				<p>Me mande um <span class="bold">e-mail</span>!</p>
			</div>
		</div>
	<br><br>
	<center> <a href="logout.php"><button> Sair</button> </a> </center> <!--Ao clicar em sair a sessão será destruida--> 
	</body>
</html>
