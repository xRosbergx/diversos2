<!DOCTYPE html>
<html>
<head  lang = "pt-br">

	<title>Sistema de Cadastro</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css"/>
	<link real="stylesheet" type="text/css" heref="css/normalize.css"/>
</head>

<div id="header">
		<p id="name">Sistema de Cadastro</p>
		<p id="imagem"><img src=img/chave.png></p>
</div>

<body>
	
		<meta charset="UTF-8">
		<form name="signup" method="post" action="cadastrando.php" id ="formulario">
			<div id="caixa">
				<div id = "alinhar">
					<label>Nome:</label> <input class="texto" type="text" required name="nome" /> 
					</br></br>
					<label>Sobrenome:</label> <input type="text" name="sobrenome" /> 
					</br></br>
					<label>Pais:</label> <input type="text" name="pais" /> 
					</br></br>
					<label>Estado:</label> <input type="text" name="estado" />
					</br></br>
					<label>Cidade:</label> <input type="text" name="cidade" /> 
					</br></br>
					<label>E-mail:</label> <input type="text" required name="email" /> 
					</br></br>
					<label>Senha:</label> <input type="password" required name="senha" /> 
					</br></br>
				</div>
				<input type="submit" id="bt" value="Cadastrar"/>
			</div>
		</form>		
</body>
</html>