<!DOCTYPE html>
<html>
<head>
	<title>cadastrando...</title>
	<script type="text/javascript"> 
		function cadastrosuccessfully(){
			setTimeout("window.location='login.php'", 5000);

		}
	</script>
</head>
<body>
	<?php
		$host = "localhost";
		$user = "root";
		$pass = "";
		$banco = "cadastro";
		$conexao = mysql_connect($host, $user, $pass) or die(mysql_error());
		mysql_select_db($banco) or die(mysql_error());
	?>
	<!--captura todas as informações que o usuario digito na pagina de cadastro-->
	<?php
		$nome=$_POST['nome'];
		$sobrenome=$_POST ['sobrenome'];
		$pais=$_POST['pais'];
		$estado=$_POST['estado'];
		$cidade=$_POST['cidade'];
		$email=$_POST['email'];
		$senha=$_POST['senha'];
		$sql = mysql_query("INSERT INTO usuarios(nome, sobrenome, pais, estado, cidade, email, senha) /*inserindo os dados da tabela usuarios*/
		VALUES('$nome', '$sobrenome', '$pais', '$estado', '$cidade', '$email', '$senha')");
		echo "<h2><center>Cadastro efetuado com sucesso!</center></h2>";
		echo "<script>cadastrosuccessfully()</script>"; // redireciona para uma nova pagina caso o cadastro esteja certo

	?>
</body>
</html>