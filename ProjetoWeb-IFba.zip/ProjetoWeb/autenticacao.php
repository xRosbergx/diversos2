<?php
		$host = "localhost";
		$user = "root";
		$pass = "";
		$banco = "cadastro";
		$conexao=mysql_connect($host, $user, $pass) or die(mysql_error());//Faz a conexão com o banco de dados OBS: die(mysql_error() envia uma msg com o erro no banco, se houver!
		mysql_select_db($banco) or die(mysql_error());
	?>


<html>
<head>
	<title>Autenticando Usuario</title>
	<script type="text/javascript"> 
		function loginsuccessfully(){
			setTimeout("window.location='painel.php'", 5000);

		}

		function loginfailed(){
			setTimeout("window.location='login.php'", 5000);

		}
	</script>
</head>

<body>

	<?php
		$email=$_POST['email'];// captura email
		$senha=$_POST['senha'];// captura senha
		$sql = mysql_query("SELECT * FROM usuarios WHERE email = '$email' and senha = '$senha'") or die(mysql_error()); // consulta se o email e senha existe na tabela usuarios
		$row = mysql_num_rows($sql);// row conta quantas linhas possui no banco de dados com as informações que o usuario digitou

		if ($row > 0) { // se o registro do usuario exisitir então
			session_start(); // iniciar uma sessão para o usuario
			$_SESSION['email']=$_POST['email'];
			$_SESSION['senha']=$_POST['senha'];
			echo "<center>Login efetuado com sucesso!</center>"; 
			echo "<script>loginsuccessfully()</script>"; // redireciona para uma nova pagina caso o login esteja certo
		} else{
			echo "<center>Nome de  usuario ou Senha invalidos.</center>";
			echo "<script>loginfailed()</script>"; //redireciona para uma nava pagina neste caso de ERRO!!!
		}
	?>

</body>
</html>
