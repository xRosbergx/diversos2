
public class No {

	int dado;
	
	No esq, dir;
	
	public No(){
		dado = 0;
		esq = null;
		dir = null;
	}
	
	public No(int dado){
		this.dado = dado;
		esq = null;
		dir = null;
	}
	
}
